<td valign="top" class="body" style="padding-bottom:10px;">
  <div id="mpesa">THANK YOU FOR MAKING YOUR RESRVATION .
    TO PAY YOUR BILL VIA MPESA USE THIS NUMBER 
    0714812921. YOU ARE EXPECTED TO PAY <?PHP echo $_SESSION['pay']; ?>
	FOR THE MOST RECENT TRANSCTION YOU MADE.
  </div>
<td>
